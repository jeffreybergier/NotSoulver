//
//  main.m
//  SLRE
//
//  Created by Jeffrey Bergier on 2025/03/18.
//

#import <Foundation/Foundation.h>
#import "slre.h"

void scan(void) {
  NSString *string = @"aaahellocccbyeaaahellocccbyeaaa";
  NSString *pattern = @"(hello)";
  NSRange range = NSMakeRange(2, [string length]-3);
  struct slre_cap caps[1] = {0};
  int status = 0;
  status = slre_match([pattern UTF8String], [string UTF8String]+range.location+status, (int)range.length-status, caps, 1, 0);
  NSLog(@"%d", status);
  NSLog(@"%@", [string substringWithRange:NSMakeRange(caps[0].ptr-[string UTF8String], caps[0].len)]);
  status = slre_match([pattern UTF8String], [string UTF8String]+range.location+status, (int)range.length-status, caps, 1, 0);
  NSLog(@"%@", [string substringWithRange:NSMakeRange(caps[0].ptr-[string UTF8String], caps[0].len)]);
  NSLog(@"%d", status);
}

int main(int argc, const char * argv[]) {
  @autoreleasepool {
    scan();
  }
  return 0;
}
